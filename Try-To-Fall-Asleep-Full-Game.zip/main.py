import time
import random

# Base class for items
class Item:
    def __init__(self, name, description, uses):
        self.name = name
        self.description = description
        self.uses = uses

    def use(self):
        if self.uses > 0:
            self.uses -= 1
            return True  # Item used successfully
        else:
            print(f"The {self.name} has no more uses.")
            return False  # No uses left


# Inventory system
class Inventory:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def remove_item(self, item_name):
        self.items = [item for item in self.items if item.name != item_name]

    def show_inventory(self):
        print("Inventory:")
        for item in self.items:
            print(f"{item.name} - {item.description} (Uses: {item.uses})")
        print("\n")

# Game variables
player_health = 100
inventory = Inventory()

monsters = {
    "Child with Hollow Eyes": {"health": 30, "effect": "hypnotizes", "behavior": "flee"},
    "Shadowy Figure": {"health": 50, "effect": "intimidates", "behavior": "attack"},
    "Eyeball Creature": {"health": 40, "effect": "paralyzes", "behavior": "lurk"},
    "Whispering Specter": {"health": 35, "effect": "confuses", "behavior": "manipulate"},
    "Wailing Banshee": {"health": 45, "effect": "screeches", "behavior": "chase"},
    "Creeping Shadow": {"health": 60, "effect": "drains sanity", "behavior": "follow"},
}


# Crafting function
def craft_item(inventory, recipe, crafted_item):
    # Check if the player has all items required for crafting
    for required_item in recipe:
        if not any(item.name == required_item for item in inventory.items):
            print(f"You don't have all the components to craft {crafted_item.name}.")
            return False

    # If all items are available, craft the item
    for required_item in recipe:
        inventory.remove_item(required_item)  # Remove used components
    inventory.add_item(crafted_item)  # Add the crafted item
    print(f"You crafted {crafted_item.name}!")
    return True


# Mini-games: Lockpicking
def lockpicking_mini_game():
    secret_number = random.randint(1, 5)  # Random number between 1 and 5
    attempts = 3

    print("Lockpicking Mini-Game: Guess the number (1-5) to unlock the door!")
    while attempts > 0:
        guess = int(input(f"Enter your guess (Attempts left: {attempts}): "))
        if guess == secret_number:
            print("Success! You unlocked the door.")
            return True
        else:
            attempts -= 1
            print("Wrong guess.")

    print("Failed! You couldn't unlock the door.")
    return False


# Mini-games: Puzzle
def puzzle_mini_game():
    correct_combination = [1, 2, 3]  # Example puzzle solution
    attempts = 3

    print("Puzzle Mini-Game: Solve the puzzle by entering the correct combination of 3 switches!")
    while attempts > 0:
        guess = [int(input(f"Enter guess for switch {i+1} (1, 2, or 3): ")) for i in range(3)]
        if guess == correct_combination:
            print("Success! You solved the puzzle.")
            return True
        else:
            attempts -= 1
            print("Wrong combination.")

    print("Failed! You couldn't solve the puzzle.")
    return False


# Monster class
class Monster:
    def __init__(self, name, health, effect, attack_description):
        self.name = name
        self.health = health
        self.effect = effect
        self.attack_description = attack_description

    def attack(self, player_health):
        print(self.attack_description)
        return player_health - 20  # Example damage

    def take_damage(self, damage):
        self.health -= damage
        print(f"The {self.name} took {damage} damage! (Health: {self.health})")
        if self.health <= 0:
            print(f"The {self.name} has been defeated.")
            return True  # Monster defeated
        return False


# Character class
class Character:
    def __init__(self, name, health):
        self.name = name
        self.health = health

    def talk(self):
        print(f"{self.name} says hello!")

    def take_damage(self, damage):
        self.health -= damage
        print(f"{self.name} takes {damage} damage! (Health: {self.health})")
        if self.health <= 0:
            print(f"{self.name} has been defeated.")
            return True  # Character defeated
        return False


def slow_print(text, delay=0.05):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()


def start_game():
    global inventory
    inventory = Inventory()  # Initialize inventory when the game starts
    slow_print("You lie in bed, staring at the ceiling, trying to fall asleep.")
    slow_print("The room is dark, and the silence is deafening.")
    slow_print("Suddenly, you hear a faint whisper coming from the corner of the room.")

    choice = input("Do you want to (1) investigate the sound or (2) pull the blanket over your head? (1/2): ")

    if choice == "1":
        investigate_sound()
    elif choice == "2":
        pull_blanket()
    else:
        slow_print("Invalid choice. Please choose 1 or 2.")
        start_game()


def investigate_sound():
    slow_print("You muster your courage and get out of bed.")
    slow_print("As you approach the corner, the whisper becomes clearer.")

    choice = input("Do you want to (1) turn on the light or (2) keep walking toward the sound? (1/2): ")

    if choice == "1":
        turn_on_light()
    elif choice == "2":
        keep_walking()
    else:
        slow_print("Invalid choice. Please choose 1 or 2.")
        investigate_sound()


def pull_blanket():
    slow_print("You pull the blanket over your head, trying to block out the sound.")
    slow_print("But the whisper grows louder, more insistent.")

    choice = input("Do you want to (1) confront the sound or (2) stay under the blanket? (1/2): ")

    if choice == "1":
        confront_sound()
    elif choice == "2":
        stay_under_blanket()
    else:
        slow_print("Invalid choice. Please choose 1 or 2.")
        pull_blanket()


def turn_on_light():
    slow_print("You turn on the light, and the room is illuminated.")
    slow_print("You see nothing but shadows.")
    slow_print("Suddenly, the light flickers and goes out!")

    choice = input("Do you want to (1) check the fuse box or (2) use your phone as a flashlight? (1/2): ")

    if choice == "1":
        check_fuse_box()
    elif choice == "2":
        use_phone_flashlight()
    else:
        slow_print("Invalid choice. Please choose 1 or 2.")
        turn_on_light()


def keep_walking():
    slow_print("As you get closer, you see a figure standing in the shadows.")
    slow_print("You can't make out any details, but it feels like it's watching you.")

    choice = input("Do you want to (1) call out to it or (2) turn back? (1/2): ")

    if choice == "1":
        call_out()
    elif choice == "2":
        turn_back()
    else:
        slow_print("Invalid choice. Please choose 1 or 2.")
        keep_walking()


def call_out():
    slow_print("You call out, 'Who's there?'")
    slow_print("The figure shifts slightly, and you hear a low growl...")
    encounter_monster()


def turn_back():
    slow_print("You turn back, feeling uneasy.")
    slow_print("But something brushes against your arm...")
    encounter_monster()


def confront_sound():
    slow_print("You throw off the blanket, determined to face the source of the sound.")
    slow_print("The whispering stops, and you feel a cold breeze on your neck.")
    encounter_monster()


def stay_under_blanket():
    slow_print("You stay under the blanket, shivering.")
    slow_print("But the whispering becomes unbearable, and you feel a presence enter the room...")
    encounter_monster()


def check_fuse_box():
    slow_print("You head to the fuse box in the hallway.")
    slow_print("As you open it, you see a strange symbol glowing inside.")
    slow_print("You need to fix the fuse box to restore power.")

    success = mini_game_fuse_box()
    if success:
        slow_print("You successfully fix the fuse box! The lights come back on.")
        slow_print("But you feel a dark presence behind you...")
        encounter_monster()
    else:
        slow_print("You failed to fix the fuse box. The darkness seems to swallow you whole...")
        slow_print("Game Over.")


def use_phone_flashlight():
    slow_print("You pull out your phone and turn on the flashlight.")
    slow_print("The beam of light cuts through the darkness, revealing a shadowy figure standing in the corner.")
    encounter_monster()


def mini_game_fuse_box():
    return lockpicking_mini_game()


def encounter_monster():
    monster_name = random.choice(list(monsters.keys()))
    monster = Monster(monster_name, monsters[monster_name]["health"], 
                      monsters[monster_name]["effect"], "It lunges at you with dark intent!")

    slow_print(f"You are facing {monster.name}! It {monster.effect}.")
    monster_attack(monster)


def monster_attack(monster):
    global player_health
    player_health = monster.attack(player_health)
    if player_health > 0:
        slow_print(f"You survived the attack, but your health is now {player_health}.")
    else:
        slow_print("You succumbed to the monster's attack...")
        slow_print("Game Over.")


# Start the game
start_game()
